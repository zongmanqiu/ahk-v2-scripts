; ==UserScript==
; @name         包测试脚本
; @version      0.1.0
; @description  多文件脚本包端到端验证
; ==/UserScript==

#Requires AutoHotkey v2.0
out := A_ScriptDir "\result.txt"
txt := FileRead(A_ScriptDir "\data\note.txt")
FileAppend("读到了：" txt "
", out)
ExitApp()
